
adicione codigo, baseado no analisador lexico TinyFlex
para analise lexica da linguagem C-

restrições

* arquivos de código devem ter extensão .c
* codigo output do flex (.c) não pode estar nesse diretorio 
  - se executou o flex manualmente, apague. O CMake executa o flex
* o arquivo .l (entrada do flex) deve se chamar cminus.l

